import requests
import json
import time
import threading
from datetime import datetime

class Orchestrator:
    def __init__(self, config_file="config_workers.json"):
        with open(config_file, 'r') as f:
            self.config = json.load(f)
        self.workers = self.config['workers']
        self.timeout = self.config['orchestrator']['timeout']
        self.retry_attempts = self.config['orchestrator']['retry_attempts']
        
    def ping_worker(self, worker):
        """Ping a un worker específico"""
        try:
            url = f"http://{worker['ip']}:{worker['port']}/ping"
            response = requests.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                worker['status'] = 'active'
                worker['last_ping'] = datetime.now().isoformat()
                print(f"✅ {worker['id']} ({worker['ip']}) - ACTIVO")
                print(f"   Worker ID: {data.get('worker_id', 'unknown')}")
                return True
            else:
                worker['status'] = 'error'
                print(f"❌ {worker['id']} ({worker['ip']}) - ERROR: {response.status_code}")
                return False
                
        except Exception as e:
            worker['status'] = 'inactive'
            print(f"❌ {worker['id']} ({worker['ip']}) - INACTIVO: {str(e)}")
            return False
    
    def ping_all_workers(self):
        """Ping a todos los workers"""
        print("🔍 Verificando estado de workers...")
        print("=" * 50)
        active_workers = []
        
        for worker in self.workers:
            if self.ping_worker(worker):
                active_workers.append(worker)
        
        print("=" * 50)
        if not active_workers:
            print("⚠️  NO HAY MÁQUINAS ACTIVAS")
            print("   Verifica que las VMs estén encendidas y ejecutando worker_service.py")
            print("   Comando en cada VM: python3 worker_service.py")
        else:
            print(f"✅ {len(active_workers)} máquinas activas de {len(self.workers)} total")
        
        return active_workers
    
    def execute_task(self, worker, task):
        """Ejecutar tarea en un worker específico"""
        try:
            url = f"http://{worker['ip']}:{worker['port']}/execute"
            print(f"🚀 Enviando tarea a {worker['id']} ({worker['ip']})...")
            
            response = requests.post(url, json=task, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Tarea completada en {worker['id']}")
                print(f"   Tiempo: {result.get('execution_time', 'N/A')} segundos")
                print(f"   Colisiones P-P: {result.get('particle_collisions', 'N/A')}")
                print(f"   Colisiones Pared: {result.get('wall_collisions', 'N/A')}")
                return result
            else:
                print(f"❌ Error en {worker['id']}: {response.status_code}")
                if response.text:
                    print(f"   Detalle: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error ejecutando en {worker['id']}: {str(e)}")
            return None
    
    def get_worker_status(self, worker):
        """Obtener estado detallado de un worker"""
        try:
            url = f"http://{worker['ip']}:{worker['port']}/status"
            response = requests.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
                
        except Exception as e:
            return None
    
    def run_demo(self):
        """Ejecutar demo completo del sistema"""
        print("🎭 DEMO DEL SISTEMA DE ORQUESTACIÓN")
        print("=" * 60)
        
        # 1. Verificar workers
        active_workers = self.ping_all_workers()
        
        if not active_workers:
            return
        
        print("\n" + "=" * 60)
        print("📊 ESTADO DETALLADO DE WORKERS")
        print("=" * 60)
        
        # 2. Obtener estado detallado
        for worker in active_workers:
            status = self.get_worker_status(worker)
            if status:
                print(f"\n🖥️  {worker['id']} ({worker['ip']}):")
                print(f"   Docker disponible: {status.get('docker_available', 'N/A')}")
                print(f"   Imagen disponible: {status.get('image_available', 'N/A')}")
                print(f"   Timestamp: {status.get('timestamp', 'N/A')}")
        
        print("\n" + "=" * 60)
        print("🧪 EJECUTANDO TAREAS DE PRUEBA")
        print("=" * 60)
        
        # 3. Ejecutar tareas de prueba
        test_tasks = [
            {
                "benchmark": "benchmark.py",
                "params": {
                    "NUM_PARTICULAS": 50,
                    "NUM_PASOS": 100,
                    "SEMILLA": 42
                }
            },
            {
                "benchmark": "benchmark_cython.py",
                "params": {
                    "NUM_PARTICULAS": 50,
                    "NUM_PASOS": 100,
                    "SEMILLA": 42
                }
            }
        ]
        
        for i, task in enumerate(test_tasks):
            if i < len(active_workers):
                worker = active_workers[i]
                print(f"\n📋 Tarea {i+1}: {task['benchmark']}")
                result = self.execute_task(worker, task)
                
                if result:
                    print("   ✅ Tarea completada exitosamente")
                else:
                    print("   ❌ Tarea falló")
            else:
                print(f"\n⏭️  Saltando tarea {i+1} - No hay workers disponibles")
        
        print("\n" + "=" * 60)
        print("🎉 DEMO COMPLETADO")
        print("=" * 60)

def main():
    orch = Orchestrator()
    
    while True:
        print("\n🎛️  SISTEMA DE ORQUESTACIÓN")
        print("1. Verificar workers")
        print("2. Ejecutar tarea específica")
        print("3. Demo completo")
        print("4. Salir")
        
        choice = input("\nSelecciona una opción (1-4): ").strip()
        
        if choice == "1":
            orch.ping_all_workers()
            
        elif choice == "2":
            active_workers = orch.ping_all_workers()
            if not active_workers:
                continue
                
            print("\nWorkers disponibles:")
            for i, worker in enumerate(active_workers):
                print(f"{i+1}. {worker['id']} ({worker['ip']})")
            
            try:
                worker_idx = int(input("Selecciona worker (número): ")) - 1
                if 0 <= worker_idx < len(active_workers):
                    selected_worker = active_workers[worker_idx]
                    
                    print("\nBenchmarks disponibles:")
                    print("1. benchmark.py (Python puro)")
                    print("2. benchmark_cython.py (Optimizado)")
                    
                    benchmark_choice = input("Selecciona benchmark (1-2): ").strip()
                    benchmark = "benchmark.py" if benchmark_choice == "1" else "benchmark_cython.py"
                    
                    particulas = int(input("Número de partículas (ej: 100): "))
                    pasos = int(input("Número de pasos (ej: 500): "))
                    semilla = int(input("Semilla (ej: 42): "))
                    
                    task = {
                        "benchmark": benchmark,
                        "params": {
                            "NUM_PARTICULAS": particulas,
                            "NUM_PASOS": pasos,
                            "SEMILLA": semilla
                        }
                    }
                    
                    orch.execute_task(selected_worker, task)
                else:
                    print("❌ Worker inválido")
                    
            except ValueError:
                print("❌ Entrada inválida")
                
        elif choice == "3":
            orch.run_demo()
            
        elif choice == "4":
            print("👋 Saliendo del orquestador...")
            break
            
        else:
            print("❌ Opción inválida")

if __name__ == "__main__":
    main()
