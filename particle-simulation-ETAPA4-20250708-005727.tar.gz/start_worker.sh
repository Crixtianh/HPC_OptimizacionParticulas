#!/bin/bash

echo "🚀 INICIANDO WORKER SERVICE"
echo "=" * 40

# Obtener IP local
LOCAL_IP=$(hostname -I | awk '{print $1}')
echo "🌐 IP Local: $LOCAL_IP"

# Determinar Worker ID basado en IP
if [[ "$LOCAL_IP" == "192.168.1.93" ]]; then
    WORKER_ID="worker-01"
elif [[ "$LOCAL_IP" == "192.168.1.155" ]]; then
    WORKER_ID="worker-02"
else
    WORKER_ID="worker-$LOCAL_IP"
fi

echo "🏷️  Worker ID: $WORKER_ID"

# Verificar que Docker esté funcionando
echo "🔍 Verificando Docker..."
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker no está funcionando. Intentando iniciar..."
    sudo systemctl start docker
    sleep 5
    
    if ! docker info > /dev/null 2>&1; then
        echo "💥 Error: No se pudo iniciar Docker"
        echo "   Ejecuta manualmente: sudo systemctl start docker"
        exit 1
    fi
fi

echo "✅ Docker está funcionando"

# Verificar que la imagen particle-simulation existe
echo "🔍 Verificando imagen particle-simulation..."
if ! docker images | grep -q "particle-simulation"; then
    echo "⚠️  Imagen particle-simulation no encontrada."
    echo ""
    echo "🔧 Para crear la imagen:"
    echo "   1. Asegúrate de que el proyecto esté extraído"
    echo "   2. cd TAREA/"
    echo "   3. docker build -t particle-simulation:latest ."
    echo ""
    read -p "¿Continuar sin la imagen? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
    echo "⚠️  Continuando sin verificar imagen..."
else
    echo "✅ Imagen particle-simulation encontrada"
fi

# Instalar dependencias Python si no están disponibles
echo "🔍 Verificando dependencias Python..."
if ! python3 -c "import flask" 2>/dev/null; then
    echo "📦 Instalando Flask..."
    pip3 install flask==2.3.3
fi

if ! python3 -c "import requests" 2>/dev/null; then
    echo "📦 Instalando requests..."
    pip3 install requests==2.31.0
fi

echo "✅ Dependencias verificadas"

# Verificar si el puerto 8080 está libre
echo "🔍 Verificando puerto 8080..."
if netstat -tuln | grep -q ":8080 "; then
    echo "⚠️  Puerto 8080 ya está en uso"
    echo "🔧 Puedes detener el proceso anterior o usar otro puerto"
    
    read -p "¿Continuar de todas formas? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Crear directorio de logs si no existe
mkdir -p logs

# Configurar variables de entorno
export WORKER_ID=$WORKER_ID
export FLASK_ENV=production

echo "=" * 40
echo "🎯 Iniciando worker service..."
echo "🌐 Accesible en: http://$LOCAL_IP:8080"
echo "🛑 Presiona Ctrl+C para detener"
echo "=" * 40

# Iniciar worker service con logging
python3 worker_service.py 2>&1 | tee logs/worker_$(date +%Y%m%d_%H%M%S).log
