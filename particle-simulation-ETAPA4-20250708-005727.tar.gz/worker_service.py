from flask import Flask, request, jsonify
import subprocess
import json
import time
import os
import socket
from datetime import datetime

app = Flask(__name__)

# Configuración global
WORKER_ID = os.getenv('WORKER_ID', 'worker-unknown')

@app.route('/ping', methods=['GET'])
def ping():
    """Endpoint para verificar que el worker está activo"""
    return jsonify({
        "status": "active",
        "timestamp": datetime.now().isoformat(),
        "worker_id": WORKER_ID,
        "message": "Worker is running and ready"
    })

@app.route('/execute', methods=['POST'])
def execute_task():
    """Endpoint para ejecutar una tarea (benchmark)"""
    try:
        task = request.get_json()
        
        if not task:
            return jsonify({
                "status": "error",
                "error": "No task data provided",
                "worker_id": WORKER_ID
            }), 400
        
        benchmark = task.get('benchmark', 'benchmark.py')
        params = task.get('params', {})
        
        # Validar benchmark
        if benchmark not in ['benchmark.py', 'benchmark_cython.py']:
            return jsonify({
                "status": "error",
                "error": f"Benchmark no válido: {benchmark}",
                "worker_id": WORKER_ID
            }), 400
        
        # Construir comando Docker
        cmd = [
            'docker', 'run', '--rm', 
            'particle-simulation:latest',
            'python', benchmark,
            str(params.get('NUM_PARTICULAS', 100)),
            str(params.get('NUM_PASOS', 1000)),
            str(params.get('SEMILLA', 42))
        ]
        
        print(f"🚀 [{WORKER_ID}] Ejecutando: {' '.join(cmd)}")
        start_time = time.time()
        
        # Ejecutar comando
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        if result.returncode == 0:
            # Parsear salida para extraer métricas
            output = result.stdout
            
            # Buscar colisiones en la salida
            particle_collisions = "N/A"
            wall_collisions = "N/A"
            
            for line in output.split('\n'):
                if "colisiones Partícula-Partícula" in line:
                    try:
                        particle_collisions = line.split(':')[-1].strip()
                    except:
                        pass
                elif "colisiones con Pared" in line:
                    try:
                        wall_collisions = line.split(':')[-1].strip()
                    except:
                        pass
            
            print(f"✅ [{WORKER_ID}] Tarea completada en {execution_time:.2f}s")
            
            return jsonify({
                "status": "success",
                "execution_time": round(execution_time, 4),
                "particle_collisions": particle_collisions,
                "wall_collisions": wall_collisions,
                "benchmark": benchmark,
                "params": params,
                "output": output,
                "worker_id": WORKER_ID,
                "timestamp": datetime.now().isoformat()
            })
        else:
            print(f"❌ [{WORKER_ID}] Error en ejecución: {result.stderr}")
            
            return jsonify({
                "status": "error",
                "error": result.stderr,
                "stdout": result.stdout,
                "execution_time": round(execution_time, 4),
                "worker_id": WORKER_ID,
                "returncode": result.returncode
            }), 500
            
    except subprocess.TimeoutExpired:
        print(f"⏰ [{WORKER_ID}] Timeout en ejecución")
        return jsonify({
            "status": "error",
            "error": "Task execution timeout (300 seconds)",
            "worker_id": WORKER_ID
        }), 500
        
    except Exception as e:
        print(f"💥 [{WORKER_ID}] Error inesperado: {str(e)}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "worker_id": WORKER_ID
        }), 500

@app.route('/status', methods=['GET'])
def get_status():
    """Endpoint para obtener estado detallado del worker"""
    try:
        # Verificar si Docker está funcionando
        docker_status = subprocess.run(['docker', 'info'], capture_output=True, timeout=10)
        docker_ok = docker_status.returncode == 0
        
        # Verificar si la imagen está disponible
        image_available = False
        if docker_ok:
            image_status = subprocess.run(
                ['docker', 'images', 'particle-simulation:latest', '--format', '{{.Repository}}'],
                capture_output=True, text=True, timeout=10
            )
            image_available = 'particle-simulation' in image_status.stdout
        
        # Información adicional del sistema
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        
        return jsonify({
            "status": "active",
            "docker_available": docker_ok,
            "image_available": image_available,
            "worker_id": WORKER_ID,
            "hostname": hostname,
            "local_ip": local_ip,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e),
            "worker_id": WORKER_ID
        }), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Endpoint simple de health check"""
    return jsonify({
        "status": "healthy",
        "worker_id": WORKER_ID,
        "timestamp": datetime.now().isoformat()
    })

def determine_worker_id():
    """Determinar ID del worker basado en la IP local"""
    try:
        # Obtener IP local
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        
        # Mapear IP a Worker ID
        ip_to_worker = {
            "192.168.1.93": "worker-01",
            "192.168.1.155": "worker-02"
        }
        
        return ip_to_worker.get(local_ip, f"worker-{local_ip}")
        
    except Exception as e:
        print(f"⚠️  Error determinando Worker ID: {e}")
        return "worker-unknown"

if __name__ == '__main__':
    # Determinar Worker ID
    if 'WORKER_ID' not in os.environ:
        WORKER_ID = determine_worker_id()
        os.environ['WORKER_ID'] = WORKER_ID
    else:
        WORKER_ID = os.getenv('WORKER_ID')
    
    print("🚀 INICIANDO WORKER SERVICE")
    print("=" * 40)
    print(f"🏷️  Worker ID: {WORKER_ID}")
    
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        print(f"🌐 IP Local: {local_ip}")
        print(f"🔌 Puerto: 8080")
        print(f"📡 Endpoints disponibles:")
        print(f"   - http://{local_ip}:8080/ping")
        print(f"   - http://{local_ip}:8080/execute")
        print(f"   - http://{local_ip}:8080/status")
        print(f"   - http://{local_ip}:8080/health")
    except Exception as e:
        print(f"⚠️  Error obteniendo IP: {e}")
    
    print("=" * 40)
    print("✅ Worker listo para recibir tareas!")
    print("🛑 Presiona Ctrl+C para detener")
    print("=" * 40)
    
    # Iniciar servidor Flask
    app.run(host='0.0.0.0', port=8080, debug=False)
